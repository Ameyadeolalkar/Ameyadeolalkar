(function () {

    angular.module('app')
        .controller('ClassroomController', [ClassroomController]);

    function ClassroomController() {

        var vm = this;

    }

}());